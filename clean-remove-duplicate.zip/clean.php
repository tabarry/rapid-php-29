<?php

function getDirContents($dir, &$results = array()) {
    $files = scandir($dir);

    foreach ($files as $key => $value) {
        $path = realpath($dir . DIRECTORY_SEPARATOR . $value);
        if (!is_dir($path)) {
            $results[] = $path;
        } else if ($value != "." && $value != "..") {
            getDirContents($path, $results);
            $results[] = $path;
        }
    }

    return $results;
}

//echo '<pre>';
//print_r(getDirContents('./'));
$output = getDirContents('./');
for ($i = 0; $i <= sizeof($output); $i++) {
    if (strstr($output[$i], ' 2.')) {
        echo $output[$i];
        unlink($output[$i]);
        echo '<br>';
    }
}

